<?= $this->extend('layout/template'); ?>

<?= $this->section('content'); ?>
<div class="container">
    <div class="row">
        <div class="col">
            <h1>Welcome!</h1>
            <div class="p-5 mb-5 bg-primary-subtle text-primary-emphasis">
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Doloremque incidunt, alias ducimus totam dolorum magnam vitae! Hic fugiat aliquid libero ab incidunt cupiditate aspernatur? Repellat ipsum illum odit voluptate excepturi.</p>
            </div>
        </div>
    </div>
</div>

<?= $this->endSection(); ?>