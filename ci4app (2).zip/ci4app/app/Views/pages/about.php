<?= $this->extend('layout/template'); ?>

<?= $this->section('content'); ?>
<div class="container">
    <div class="row">
        <div class="col">
            <h1>About Me</h1>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Non expedita eos repellendus. Animi voluptatum explicabo cum corrupti et fugit eum, corporis, ipsum pariatur perferendis cupiditate distinctio tenetur, ipsa id laudantium.</p>

        </div>
    </div>
</div>
<?= $this->endSection(); ?>