<?php

namespace App\Controllers;

class Pages extends BaseController
{
    public function index()
    {

        $data = [
            'title' => 'Home | UTS_51220046',

        ];

        return view('pages/home', $data);
    }

    public function about()
    {
        $data = [
            'title' => 'About Me | 51220046'
        ];
        return view('pages/about', $data);
    }

    public function contact()
    {
        $data = [
            'title' => 'Contact Us | 51220046',
            'alamat' => [
                [
                    'tipe' => 'Rumah',
                    'alamat' => 'Jl.abc No. 123',
                    'kota' => 'Bandung'
                ],
                [
                    'tipe' => 'Kantor',
                    'alamat' => 'Jl. Setiabudi No. 193',
                    'kota' => 'Bandung'
                ]
            ]
        ];
        return view('pages/contact', $data);
    }

    public function komik()
    {
        $data = [
            'title' => 'komik | 51220046'
        ];
        return view('pages/komik_51220046', $data);
    }
}
