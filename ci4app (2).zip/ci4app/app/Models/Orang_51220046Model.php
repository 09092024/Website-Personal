<?php

namespace App\Models;

use CodeIgniter\Model;

class Orang_51220046Model extends Model
{
    protected $table = 'orang_51220046';
    protected $useTimestamps = true;
    protected $allowedFields = ['nama', 'alamat'];

    public function search($keyword)
    {
        // Menggunakan properti $table yang sudah didefinisikan
        return $this->like('nama', $keyword)->orLike('alamat', $keyword)->orLike('alamat', $keyword);
    }
}
