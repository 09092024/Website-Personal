<?php

namespace App\Models;

use CodeIgniter\Model;

class Komik_51220046Model extends Model
{
    protected $table = 'komik_51220046';
    protected $useTimestamps = true;
    protected $allowedFields = ['judul', 'slug', 'penulis', 'penerbit', 'sampul'];


    public function getKomik($slug = false)
    {
        if ($slug === false) {
            return $this->findAll();
        }

        return $this->where(['slug' => $slug])->first();
    }
}
